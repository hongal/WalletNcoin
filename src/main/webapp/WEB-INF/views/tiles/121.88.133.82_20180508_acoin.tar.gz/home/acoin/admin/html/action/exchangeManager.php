<?

if ($actionType == 'regist')
{
	$name = utf8($name);
	$url = utf8($url);
	$cap = utf8($cap);
	$tel = utf8($tel);
	$email = utf8($email);
	$others = utf8($others);
	$memo = utf8($memo);

	$sql = "select max(rank)+1 from cryptocurrencyExchange";
	$nextRank = $DB -> dbGetOne($sql);

	if ($rank > $nextRank)
	{
		$rank = $nextRank;
	}

	$rankUpdate = false;
	if (@$rank && $rank > 0)
	{
		$sql = "select count(*) from cryptocurrencyExchange where rank=$rank";
		$rankDupChk = $DB -> dbGetOne($sql);

		if ($rankDupChk > 0)
		{
			$sql = "update cryptocurrencyExchange set rank=rank+1 where rank>=$rank";
			$rs1 = $DB -> dbQuery($sql);

			if ($rs1)
			{
				$rankUpdate = true;
			}
		}
		else
		{
			$rankUpdate = true;
		}
	}
	else
	{
		$rank = $nextRank;

		$rankUpdate = true;
	}

	if ($rankUpdate)
	{
		$sql = "insert into cryptocurrencyExchange set "
			."rank='{$rank}', "
			."name='{$name}', "
			."url='{$url}', "
			."cap='{$cap}', "
			."tel='{$tel}', "
			."email='{$email}', "
			."others='{$others}', "
			."memo='{$memo}', "
			."regUserId='{$_SESSION[ADMIN_USERID]}', "
			."regIpAddr='{$_SERVER[REMOTE_ADDR]}', "
			."regDate=now()";
		$rs = $DB -> dbQuery($sql);

		if ($rs)
		{
			$msg = "�ŷ��Ұ� �߰��Ǿ����ϴ�.";
		}
		else
		{
			$msg = "�ŷ��� �߰� �� ������ �߻��߽��ϴ�.";

			if (@$rank && $rank > 0 && $rankDupChk > 0)
			{
				$sql = "update cryptocurrencyExchange set rank=rank-1 where rank>=$rank";
				$rs = $DB -> dbQuery($sql);
			}
		}
	}
	else
	{
		$msg = "�ŷ��� �߰� �� ������ �߻��߽��ϴ�.";
	}

	alertUrl($msg, "{$homeUrl}?view=exchangeList");
}
else if ($actionType == 'modify')
{
	if ($idx)
	{
		$sql = "select count(*) from cryptocurrencyExchange where idx='$idx' limit 1";
		$exchangeChk = $DB -> dbGetOne($sql);

		if ($exchangeChk > 0)
		{
			$sql = "select max(rank)+1 from cryptocurrencyExchange";
			$nextRank = $DB -> dbGetOne($sql);

			if ($rank > $nextRank)
			{
				$rank = $nextRank;
			}

			$rankUpdate = false;
			if (@$rank && $rank > 0 && $rank != $rankOrigin)
			{
				$sql = "select count(*) from cryptocurrencyExchange where rank=$rank";
				$rankDupChk = $DB -> dbGetOne($sql);

				if ($rankDupChk > 0)
				{
					$sql = "update cryptocurrencyExchange set rank=rank-1 where rank>=$rankOrigin";
					$rs1 = $DB -> dbQuery($sql);

					$sql = "update cryptocurrencyExchange set rank=rank+1 where rank>=$rank";
					$rs1 = $DB -> dbQuery($sql);

					if ($rs1)
					{
						$rankUpdate = true;
					}
				}
				else
				{
					$rankUpdate = true;
				}
			}
			else
			{
				$rank = $nextRank;

				$rankUpdate = true;
			}

			if ($rankUpdate)
			{
				$name = utf8($name);
				$url = utf8($url);
				$cap = utf8($cap);
				$tel = utf8($tel);
				$email = utf8($email);
				$others = utf8($others);
				$memo = utf8($memo);

				$sql = "update cryptocurrencyExchange set "
					."rank='{$rank}', "
					."name='{$name}', "
					."url='{$url}', "
					."cap='{$cap}', "
					."tel='{$tel}', "
					."email='{$email}', "
					."others='{$others}', "
					."memo='{$memo}', "
					."updUserId='{$_SESSION[ADMIN_USERID]}', "
					."updIpAddr='{$_SERVER[REMOTE_ADDR]}', "
					."updDate=now() "
					."where idx='$idx'";
				$rs = $DB -> dbQuery($sql);

				if ($rs)
				{
					$msg = "�ŷ��Ұ� �����Ǿ����ϴ�.";
				}
				else
				{
					$msg = "�ŷ��� ���� �� ������ �߻��߽��ϴ�.";

					if (@$rank && $rank > 0 && $rank != $rankOrigin && $rankDupChk > 0)
					{
						$sql = "update cryptocurrencyExchange set rank=rank-1 where rank>=$rank";
						$rs = $DB -> dbQuery($sql);
					}
				}
			}
			else
			{
				$msg = "�ŷ��� ���� �� ������ �߻��߽��ϴ�.";
			}
		}
		else
		{
			$msg = "�߸��� �����Դϴ�.";
		}
	}
	else
	{
		$msg = "�߸��� �����Դϴ�.";
	}

	alertUrl($msg, "{$homeUrl}?view=exchangeList");
}
else if ($actionType == 'delete')
{
	if ($targetid)
	{
		$sql = "select count(*) from cryptocurrencyExchange where idx='$targetid' limit 1";
		$exchangeChk = $DB -> dbGetOne($sql);

		if ($exchangeChk > 0)
		{
			$sql = "delete from cryptocurrencyExchange where idx='$targetid'";
			$rs = $DB -> dbQuery($sql);

			if ($rs)
			{
				$msg = "�ŷ��Ұ� �����Ǿ����ϴ�.";

				$sql = "update cryptocurrencyExchange set rank=rank-1 where rank>=$rank";
				$rs = $DB -> dbQuery($sql);
			}
			else
			{
				$msg = "�ŷ��� ���� �� ������ �߻��߽��ϴ�.";
			}
		}
		else
		{
			$msg = "�߸��� �����Դϴ�.";
		}
	}
	else
	{
		$msg = "�߸��� �����Դϴ�.";
	}

	if ($isAjax == true)
	{
		echo $msg;
	}
	else
	{
		$msg = str_replace("\n","\\n",$msg);
		alertBack($msg);
	}
}
?>