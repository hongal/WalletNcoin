<?php
/********************************************************************************

�����̸� : index.php
���ϼ��� : ����
�ۼ����� : 2012/01/17
�� �� �� : webwiz
��    �� : ����

- �������� -


********************************************************************************/
@header("Content-Type: text/html;charset=EUC-KR");
session_start();
//error_reporting(E_ALL);
//ini_set("display_errors", 1);
error_reporting(E_ALL ^ E_NOTICE);

$view = empty($_POST['view'])?$_GET['view']:$_POST['view'];
$action = empty($_POST['action'])?$_GET['action']:$_POST['action'];

include_once $_SERVER['DOCUMENT_ROOT'].'/common/common.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/common/function.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/class/db.class.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/class/page.class.php';

if(!$_SESSION['ADMIN_USERID'])
{
	if($_POST['userid'] && $_POST['passwd'] && $ADMIN_ARRAY[$_POST['userid']]==$_POST['passwd'])
	{
		$_SESSION['ADMIN_USERID'] = $_POST['userid'];
	}

	if(!$_SESSION['ADMIN_USERID'])
	{
		$loginForm = <<<___njh89z___
			
			<!DOCTYPE html>
			<html>
			<head>
			<meta http-equiv="Content-Type" content="text/html; charset=euc-kr"/>
			<style>
				input{border:1px solid #aaa;margin:5px;padding:2px}
				#login {width:250px;background-color:#eee;padding:10px;margin:100px auto 0}
				#login .title{font-size:16px;font-weight:bolder}
				.userid {margin-top:8px}
				.label{display:inline-block;width:80px;font-size:12px;}
				.submit{text-align:right}
			</style>
			</head>
			<body onload="document.loginForm.userid.focus()">
			
			<form name="loginForm" method="post" action="$homeUrl" accept-charset="euc-kr">
				<div id="login">
					<span class="title">�ذ����� �α���</span>
					<div class="userid">
						<span class="label">���̵�</span>
						<input type="text" name="userid"/>
					</div>
					<div class="passwd">
						<span class="label">��й�ȣ</span>
						<input type="password" name="passwd"/>
					</div>
					<div class="submit">
						<input type="submit" value="�α���"/>
					</div>
				</div>
			</form>

			</body>
			</html>

___njh89z___;

		echo $loginForm;
		exit;
	}
}

// DB ����
if($layoutSelect[$view]['dbCon'] == 'Y')
{
	$DB = new mysqlDataBase($dbServer,$dbUser,$dbPasswd,$dbName);
	$DB -> dbConnect();
}
if($layoutSelect[$view]['anceDbCon'] == 'Y')
{
	$anceDB = new mysqlDataBase($anceDbServer,$anceDbUser,$anceDbPasswd,$anceDbName);
	$anceDB -> dbConnect();
}

if($layoutSelect[$view]['layout'] == 'no')
{
	include_once $_SERVER['DOCUMENT_ROOT'].'/action/'.$action.'.php';
}
else
{
	include_once $_SERVER['DOCUMENT_ROOT'].'/layout/'.$layoutSelect[$view]['layout'].'.php';
}

// DB ���� ����
if($layoutSelect[$view]['dbCon'] == 'Y')
{
	$DB -> dbClose();
}
if($layoutSelect[$view]['anceDbCon'] == 'Y')
{
	$anceDB -> dbClose();
}

// ���
echo $totalHtml;

?>