<?php
/********************************************************************************

�����̸� : profitAnalysis.php
���ϼ��� : ���ͺм�
�ۼ����� : 2017-12-11
�� �� �� : lills1
��    �� : ���ͺм�

- �������� -
********************************************************************************/

#--------------------------------------------------------------------------------
# �Ķ����, ����¡
#--------------------------------------------------------------------------------
$page = $_GET['page'] ? $_GET['page'] : 1;

$dateS = '2017-06-24';
$dateE = date('Y-m-d');

$totalCnt = dateDiff('day',$dateS,$dateE);
$articleCnt = 15;

$pageClass = new pageNavi($totalCnt,$articleCnt,10,$page,"view=$view");

$pageNavi = $pageClass -> getPageNavi();
$startLimit = $pageClass -> startLimit();
#--------------------------------------------------------------------------------


#--------------------------------------------------------------------------------
# type => 0: �湮, 1: ����, 2: Ż��, 3: ���Լ���, 4: TnkAd����, 5: Nas����, 6:����
#--------------------------------------------------------------------------------
$sql = "select date(create_time) as history_date, `type` as history_type, count(*) as history_value1, sum(param1) as history_value2 from histories where create_time>='2014-06-01' group by date(create_time), `type` order by date(create_time) desc";
$rs = $DB -> dbQuery($sql);

$profitArr = array();
while($result = @mysql_fetch_array($rs))
{
	$profitArr[$result['history_type']][$result['history_date']]['cnt'] = $result['history_value1'] ? $result['history_value1'] : '0';
	$profitArr[$result['history_type']][$result['history_date']]['val'] = $result['history_value2'] ? $result['history_value2'] : $result['history_value1'];
}
@mysql_free_result($rs);

switch($mode)
{
	case 'year':
		$dateChk = date('Y',strtotime("-{$startLimit} year",strtotime($dateE)));
	break;

	case 'month':
		$dateChk = date('Y-m',strtotime("-{$startLimit} month",strtotime($dateE)));
	break;

	case 'day':
		$dateChk = date('Y-m-d',strtotime("-{$startLimit} day",strtotime($dateE)));
	break;

	default:
		$dateChk = date('Y-m-d',strtotime("-{$startLimit} day",strtotime($dateE)));
}

$maxNum = $totalCnt - ($page-1) * $articleCnt;
$minNum = $maxNum - $articleCnt;

for($i=$maxNum;$i>$minNum && $i>0;$i--)
{
	if(date('Y',strtotime($dateChk))==date('Y'))
	{
		$dateView = date('m�� d��',strtotime($dateChk));
	}
	else
	{
		$dateView = date('y�� m�� d��',strtotime($dateChk));
	}

	$weekend = date('N',strtotime($dateChk));
	
	if($weekend=='6')
	{
		$weekendClass = 'bgSky';
	}
	else if($weekend=='7')
	{
		$weekendClass = 'bgRed';
	}
	else
	{
		$weekendClass = 'bgGray';
	}

	$profitList.=<<<___lills1___

		<tr onmouseover='this.style.backgroundColor="#f2f7f2"' onmouseout='this.style.backgroundColor="#FFFFFF"' bgcolor="#FFFFFF">
			<td height="30" align="center" class="LoginText2 $weekendClass">$dateView</td>

			<td align="center" class="LoginText2 bgRed">{$profitArr[0][$dateChk]['val']}</td>
			<td align="center" class="LoginText2 bgRed">{$profitArr[1][$dateChk]['val']}</td>
			<td align="center" class="MarketText9 bgYellow">{$profitArr[2][$dateChk]['val']}</td>
			<td align="center" class="LoginText2 bgRed">{$profitArr[3][$dateChk]['val']}</td>

			<td align="center" class="MarketText9 bgYellow" title="{$profitArr[4][$dateChk]['cnt']}��">{$profitArr[4][$dateChk]['val']}</td>
			<td align="center" class="MarketText9 bgYellow" title="{$profitArr[5][$dateChk]['cnt']}��">{$profitArr[5][$dateChk]['val']}</td>
			<td align="center" class="LoginText2 bgSky" title="{$profitArr[6][$dateChk]['cnt']}��">{$profitArr[6][$dateChk]['val']}</td>
		</tr>

___lills1___;

	$dateChk = date('Y-m-d',strtotime('-1 day',strtotime($dateChk)));
}
#--------------------------------------------------------------------------------


#--------------------------------------------------------------------------------
# Ż�� ȸ����
#--------------------------------------------------------------------------------
$sql = "select count(*) as cnt from withdraw";
$delMemCnt = $DB -> dbGetOne($sql);
#--------------------------------------------------------------------------------


#--------------------------------------------------------------------------------
# ȸ����
#--------------------------------------------------------------------------------
$sql = "select deleted, if(device_token!='',1,0) as push, count(*) as cnt from users group by deleted, if(device_token!='',1,0)";
$rs = $DB -> dbQuery($sql);
while($result = @mysql_fetch_array($rs))
{
	if($result['deleted'] == '0')
	{
		$totalMemCnt+= $result['cnt'];
	}
	else if($result['deleted'] == '1')
	{
		$delMemCnt+= $result['cnt'];
	}
	
	if($result['push'] == '1')
	{
		$pushMemCnt+= $result['cnt'];
	}
}
@mysql_free_result($rs);
#--------------------------------------------------------------------------------

$contentHtml=<<<___wiz___

	<table border="0" cellspacing="0" cellpadding="0" style="margin:7px">
		<tr>
			<td height="35" align="center" class="LoginText2 bgRed" style="border:1px solid #93bb93;border-top:2px solid #93bb93;">
				<b style="font-size:1.2em">��ȸ�� $totalMemCnt, Ǫ��ȸ�� $pushMemCnt, Ż��ȸ�� $delMemCnt</b>
			</td>
		</tr>
		<tr>
			<td bgcolor="#93bb93">
				<table border="0" cellspacing="1" cellpadding="0">
					<tr>
						<td height="45" width="100" align="center" class="MyMoneyText1 bgGreen" >��¥</td>
						<td width="80" align="center" class="saleTitle bgGray" >�湮</td>
						<td width="80" align="center" class="saleTitle bgGray" >����</td>
						<td width="80" align="center" class="saleTitle bgGray" >Ż��</td>
						<td width="80" align="center" class="saleTitle bgGray" >���Լ���</td>
						<td width="80" align="center" class="saleTitle bgGray" >TnkAd����</td>
						<td width="80" align="center" class="saleTitle bgGray" >Nas����</td>
						<td width="80" align="center" class="saleTitle bgGray" >����</td>
					</tr>
					$profitList

				</table>
			</td>
		</tr>
		<tr>
			<td height="30" align="center"><br><br>$pageNavi<br><br></td>
		</tr>
		<tr>
			<td>
				<div style="border:1px solid #d5d5d5; background-color:#f5f5f5; padding:10px;">
					..
				</div>
			</td>
		</tr>
	</table>

___wiz___;

?>