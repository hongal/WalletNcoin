<?php
#====================================================================================================
#	���� : �ŷ��� ���
#	�ۼ� : 2017-08-08 lills1
#	���� :
#
#====================================================================================================
$searchType = $_GET['searchType'];
$query = $_GET['query'];
$page = $_GET['page'];
$type = $_GET['type'];


#================================================================================
# ����
#================================================================================
$articleCnt = 100;
$pageCnt = 10;
$page = $page ? $page : 1;
$tableWidth = '1340px';
#================================================================================


#================================================================================
# ���͸�
#================================================================================
if($type == 'search' && $searchType && $query)
{
	if(@in_array($searchType, array('name','url','cap','tel','email','others','memo')))
	{
		$searchQuery = " and {$searchType} like '$query%'";
	}
	else
	{
		$searchQuery = " and {$searchType}='$query'";
	}

	$searchTypeSelected[$searchType] = 'selected';
}

$orderQuery = ($orderQuery)?$orderQuery:'order by idx desc';
#================================================================================


#================================================================================
# ����¡
#================================================================================
$sql = "select count(*) from cryptocurrencyExchange where 1=1 {$addQuery} {$searchQuery}";
$totalCnt = $DB -> dbGetOne($sql);

$pageClass = new pageNavi($totalCnt,$articleCnt,10,$page,"view=$view&type=$type&searchType=$searchType&query=$query");

$pageNavi = $pageClass -> getPageNavi();
$startLimit = $pageClass -> startLimit();
#================================================================================


#================================================================================
# exchange ������
#================================================================================
$exchangeColumns = array(
	'get' => array(
		'idx', 'rank', 'name', 'url', 'cap', 'tel', 'email', 'others', 'memo'
	),
	'set' => array(
		#'' => ''
	)
);

$sql = "select * from cryptocurrencyExchange where 1=1 {$addQuery} {$searchQuery} {$orderQuery} limit $startLimit,$articleCnt";
$rs = $DB -> dbQuery($sql);

$artNum = $totalCnt - ($page - 1) * $articleCnt;
while ($result = @mysql_fetch_array($rs))
{
	#----------------------------------------------------------------------------
	# ����
	#----------------------------------------------------------------------------
	foreach ($exchangeColumns['get'] as $columnName)
	{
		$$columnName = cp949($result[$columnName]);
	}
	foreach ($exchangeColumns['set'] as $columnName => $varName)
	{
		$$varName = cp949($result[$columnName]);
	}
	#----------------------------------------------------------------------------


	#----------------------------------------------------------------------------
	# ����
	#----------------------------------------------------------------------------
	$manageBox = <<<___lills1___

		<div style="padding-bottom:4px;">
			<a href="{$homeUrl}?view=exchangeRegist&type=modify&idx=$idx">[����]</a>
		</div>

		<div style="padding-bottom:4px;">
			<a href="#" onclick="exchangeManager('delete','$idx','$rank');return false;">[����]</a>
		</div>

___lills1___;
	#----------------------------------------------------------------------------


	#----------------------------------------------------------------------------
	# ���
	#----------------------------------------------------------------------------
	$bgColor = '#FFFFFF';

	$list.=<<<___lills1___

		<tr onmouseover='this.style.backgroundColor="#f2f7f2"' onmouseout='this.style.backgroundColor="$bgColor"' bgcolor="$bgColor">
			<td height="40" align="center" class="LoginText2 bgGray" style="padding:7px 2px 2px 2px;">$artNum</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$rank</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$name</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$url</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$cap</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$tel</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$email</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$others</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$memo</td>
			<td align="center" style="padding:7px 2px 2px 2px; word-break:break-all;">$manageBox</td>
		</tr>

___lills1___;
	#----------------------------------------------------------------------------

	$artNum--;
}
@mysql_free_result($rs);

if(!$list)
{
	$list.=<<<___lills1___

		<tr>
			<td height="30" align="center" colspan="11" bgcolor="#FFFFFF">�˻� ����� �������� �ʽ��ϴ�.</td>
		</tr>

___lills1___;

}
#================================================================================



#================================================================================
# �ڹٽ�ũ��Ʈ
#================================================================================
$javascript.=<<<___lills1___

	function exchangeManager(actionType, targetid, rank)
	{
		var errorCheck = false;

		if(actionType == 'delete')
		{
			typeView = '����';
		}

		if (errorCheck == true)
		{
			alert('�߸��� ���� �Դϴ�.');
		}
		else
		{
			if(confirm('[ '+targetid+' ] '+typeView+' ��Ű�ڽ��ϱ�?'))
			{
				$.ajax({
					type:'POST',
					url:'?view=action&action=exchangeManager&actionType='+actionType+'&targetid='+targetid+'&rank='+rank+'&isAjax='+true,
					dataType:'html',
					success:function (html,textStatus){
						alert(html);
					},
					error:function (xhr,textStatus,errorThrown){
						//alert('error'+(errorThrown?errorThrown:xhr.status));
					}
				});
			}
		}
	}

___lills1___;
#================================================================================



#================================================================================
# ���� ���̺�
#================================================================================
$contentHtml=<<<___lills1___

	<table width="$tableWidth" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td height="20" style="padding:0 0 0 10px;">
				<table border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td width="7"><img src="$defaultImg/MarketReadIcon3.gif" alt="" width="4" height="5" style="padding-bottom:3px"/></td>
						<td class="CopyText2">�ŷ��� �˻�</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td bgcolor="#FFFFFF" style="padding:0 7px 0 7px">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td height="1" bgcolor="#7bae7c"></td>
					</tr>
					<tr>
						<td bgcolor="#93bb93">
							<table width="100%" border="0" cellspacing="1" cellpadding="0">
								<tr>
									<td width="80" height="40" align="center" class="MyMoneyText1 bgGreen">�˻�</td>
									<td class="MyMoneyText1 bgGreen">
										<form name="searchForm" method="get" action="$homeUrl">
											<input type="hidden" name="view" value="$view"/>
											<input type="hidden" name="type" value="search"/>

											<table border="0" cellspacing="5" cellpadding="0">
												<tr>
													<td>
														<select name="searchType">
															<option value="name" {$searchTypeSelected['name']}>�̸�</option>
															<option value="description" {$searchTypeSelected['description']}>����</option>
														</select>
													</td>
													<td><input type="text" name="query" class="MarketText3" value="$query"></td>
													<td><input type="image" src="$defaultImg/MyMoneyBut4.gif" alt="" width="40" height="17"></td>
												</tr>
											</table>
										</form>
									</td>
									<td width="50" class="MyMoneyText1 bgGreen">
										<table border="0" cellspacing="5" cellpadding="0">
											<tr>
												<td>
													<input type="button" onclick="location.href='{$homeUrl}?view=exchangeRegist';" value="�߰�">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<br/>

	<table width="$tableWidth" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td height="20" style="padding:0 0 0 10px;">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td width="7"><img src="$defaultImg/MarketReadIcon3.gif" alt="" width="4" height="5" style="padding-bottom:3px"/></td>
						<td class="CopyText2">�ŷ��� ���</td>
						<td align="right" style="padding-right:10px;padding-bottom:5px;font-size:12px;" class="b"></td>
					</tr>
				</table>
			</td>
		</tr>

		<tr>
			<td bgcolor="#FFFFFF" style="padding:0 7px 0 7px">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td height="1" bgcolor="#7bae7c"></td>
					</tr>
					<tr>
						<td bgcolor="#93bb93">
							<table width="100%" border="0" cellspacing="1" cellpadding="0">
								<tr>
									<td width="60" height="50" align="center" class="MyMoneyText1 bgGreen">��ȣ</td>
									<td width="60" align="center" class="MyMoneyText1 bgGreen">����</td>
									<td width="120" align="center" class="MyMoneyText1 bgGreen">name</td>
									<td width="200" align="center" class="MyMoneyText1 bgGreen">url</td>
									<td width="100" align="center" class="MyMoneyText1 bgGreen">cap</td>
									<td width="140" align="center" class="MyMoneyText1 bgGreen">tel/h.p</td>
									<td width="200" align="center" class="MyMoneyText1 bgGreen">e-mail</td>
									<td width="200" align="center" class="MyMoneyText1 bgGreen">the others</td>
									<td width="200" align="center" class="MyMoneyText1 bgGreen">���</td>
									<td width="60" align="center" class="MyMoneyText1 bgGreen">����</td>
								</tr>

								$list

							</table>
						</td>
					</tr>
					<tr>
						<td height="30" align="center">$pageNavi</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>

	<br><br><br>
___lills1___;
#================================================================================

?>