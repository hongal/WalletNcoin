function timestampToDateTime(timestamp) {
	var date = new Date(timestamp);

	var chgTimestamp = date.getFullYear().toString() + "-"
			+ addZero((date.getMonth() + 1).toString()) + "-"
			+ addZero(date.getDate().toString()) + " "
			+ addZero(date.getHours().toString()) + ":"
			+ addZero(date.getMinutes().toString()) + ":"
			+ addZero(date.getSeconds().toString());

	return chgTimestamp;
}

function addZero(data) {
	return (data < 10) ? "0" + data : data;
}