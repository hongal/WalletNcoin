<?php
#================================================================================
#	���� : �ŷ��� �߰�
#	�ۼ� : 2017-12-15 lills1
#	���� : 
#	 - 
#================================================================================

$type = ($_GET['type'] == 'modify') ? $_GET['type'] : 'regist';
$typeKr = ($type == 'modify') ? '����' : '�߰�';
$idx = $_GET['idx'];

if ($type == 'modify')
{
	if ($idx)
	{
		$sql = "select * from cryptocurrencyExchange where idx='$idx'";
		$rs = $DB -> dbQuery($sql);
		$result = @mysql_fetch_array($rs);

		if (@$result['idx'] != $idx)
		{
			alertBack('�߸��� ���� �Դϴ�.');
		}
		else
		{
			foreach ($result as $key => $val)
			{
				$$key = cp949($val);
			}
		}
	}
	else
	{
		alertBack('�߸��� ���� �Դϴ�.');
	}
}



#================================================================================
# �ڹٽ�ũ��Ʈ
#================================================================================
$javascript.=<<<___lills1___

	function inputCheck()
	{
		var fn = document.forms.exchangeForm;

		if(!fn.name.value)
		{
			alert('�ŷ��Ҹ��� �Է��ϼ���.');
			fn.name.focus();
			return false;
		}
		
		if (!confirm('�ŷ��Ҹ� {$typeKr}�Ͻðڽ��ϱ�?'))
		{
			return false;
		}
	}

___lills1___;
#================================================================================



#================================================================================
# ���� Html
#================================================================================
$contentHtml=<<<___lills1___

	<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td height="20" style="padding:0 0 0 10px;">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td width="7"><img src="$defaultImg/MarketReadIcon3.gif" alt="" width="4" height="5" style="padding-bottom:3px"/></td>
						<td class="CopyText2">�ŷ��� {$typeKr}</td>
						<td align="right" style="padding-right:10px;padding-bottom:5px;font-size:12px;" class="b"></td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td bgcolor="#FFFFFF" style="padding:0 7px 0 7px">

				<form name="exchangeForm" method="post" action="$homeUrl" onsubmit="return inputCheck();">
				<input type="hidden" name="view" value="action"/>
				<input type="hidden" name="action" value="exchangeManager"/>
				<input type="hidden" name="actionType" value="$type"/>
				<input type="hidden" name="idx" value="$idx"/>
				<input type="hidden" name="rankOrigin" value="$rank"/>

				<table width="600" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td height="1" bgcolor="#7bae7c"></td>
					</tr>
					<tr>
						<td bgcolor="#93bb93">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100" height="40" align="center" class="MyMoneyText1 bgGreen">name</td>
									<td class="MyMoneyText1 bgGreen" style="padding-left:15px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td width="100" align="left">
													<input type="text" name="name" value="$name" style="width:96%;">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100" height="40" align="center" class="MyMoneyText1 bgGreen">rank</td>
									<td class="MyMoneyText1 bgGreen" style="padding-left:15px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td width="100" align="left">
													<input type="text" name="rank" value="$rank" style="width:96%;">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100" height="40" align="center" class="MyMoneyText1 bgGreen">url</td>
									<td class="MyMoneyText1 bgGreen" style="padding-left:15px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td width="100" align="left">
													<input type="text" name="url" value="$url" style="width:96%;">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100" height="40" align="center" class="MyMoneyText1 bgGreen">cap</td>
									<td class="MyMoneyText1 bgGreen" style="padding-left:15px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td width="100" align="left">
													<input type="text" name="cap" value="$cap" style="width:96%;">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100" height="40" align="center" class="MyMoneyText1 bgGreen">tel/h.p</td>
									<td class="MyMoneyText1 bgGreen" style="padding-left:15px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td width="100" align="left">
													<input type="text" name="tel" value="$tel" style="width:96%;">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100" height="40" align="center" class="MyMoneyText1 bgGreen">e-mail</td>
									<td class="MyMoneyText1 bgGreen" style="padding-left:15px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td width="100" align="left">
													<input type="text" name="email" value="$email" style="width:96%;">
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100" height="40" align="center" class="MyMoneyText1 bgGreen">the others</td>
									<td class="MyMoneyText1 bgGreen" style="padding-left:15px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td width="100" align="left">
													<textarea name="others" style="width:95.7%; height:60px;">{$others}</textarea>
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="100" height="90" align="center" class="MyMoneyText1 bgGreen">���</td>
									<td class="MyMoneyText1 bgGreen" style="padding-left:15px;">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td width="100" align="left">
													<textarea name="memo" style="width:95.7%; height:60px;">{$memo}</textarea>
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td height="1" bgcolor="#7bae7c"></td>
					</tr>
					<tr>
						<td height="40" align="center"><input type="submit" value="{$typeKr}�ϱ�"></td>
					</tr>
				</table>

				</form>

			</td>
		</tr>
	</table>

	<script>
		changeSendType(document.getElementById('sendType').value);
	</script>

___lills1___;
#================================================================================

?>