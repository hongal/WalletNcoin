<?php
/********************************************************************************

�����̸� : default.php
���ϼ��� : default layout
�ۼ����� : 2012/02/16
�� �� �� : webwiz
��    �� : default layout

- �������� -

********************************************************************************/

include_once $_SERVER['DOCUMENT_ROOT'].'/include/top.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/include/left.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/content/'.$view.'.php';

$totalHtml=<<<___wiz___

	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>$htmlTitle</title>
		<meta http-equiv="Content-Type" content="text/html; charset=euc-kr"/>
		<meta name="description" content="$metaDescription"/>
		<meta name="keywords" content="$metaKeywords"/>
		<meta name="robots" content="all"/>
		<meta name="robots" content="index,follow"/>
		<link rel="stylesheet" href="css/$styleSheet" type="text/css"/>
		<link rel="stylesheet" href="css/dtree.css" type="text/css"/>
		<link rel="stylesheet" href="css/common.css?1" type="text/css"/>
		<script type="text/javascript" src="js/jquery-1.5.2.min.js"></script>
		<script type="text/javascript" src="js/common.js?160122"></script>
		<script src="js/dtree.js" type="text/javascript"></script>	
		<script language="javascript" type="text/javascript">
			//<![CDATA[
			$javascript
			//]]>
		</script>
	</head>

	<body onload="$bodyOnload">

		<table width="100%" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td align="center">$topHtml</td>
			</tr>
			<tr>
				<td style="padding-top:10px;">
					<table width="100%" cellpadding="0" cellspacing="0" border="0">
						<tr>
							<td width="230" valign="top">$leftHtml</td>
							<td valign="top" style="padding-left:5px;">$contentHtml</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td align="center">$bottomHtml</td>
			</tr>

		<div id="divCal" style="position:absolute;left:100;top:100;display:none;" onmouseout="HideCalendar()" onmouseover="ShowCalendar()"></div>

	</body>
	</html>

___wiz___;

?>