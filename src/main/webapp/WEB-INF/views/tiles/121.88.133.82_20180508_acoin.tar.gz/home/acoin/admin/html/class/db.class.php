<?php
/********************************************************************************

�����̸� : db.class.php
���ϼ��� : �����ͺ��̽� Ŭ����
�ۼ����� : 2007/08/10
�� �� �� : webwiz
��    �� : �����ͺ��̽� ���� �� ���� ����� ���� Ŭ����

- �������� -


********************************************************************************/

class mysqlDataBase
{
	var $dbConn;
	var $dbServer;
	var $dbUser;
	var $dbPass;
	var $dbName;

	function mysqlDataBase( $dbServer, $dbUser, $dbPass, $dbName )
	{
		$this->dbServer = $dbServer;
		$this->dbUser = $dbUser;
		$this->dbPass = $dbPass;
		$this->dbName = $dbName;
	}

	function dbConnect($now = false)
	{
		if($now)
		{
			$this -> dbConn = @mysql_connect($this -> dbServer,$this -> dbUser, $this -> dbPass) or die(mysql_error());//or die('db connect error');

			@mysql_select_db($this -> dbName, $this -> dbConn) or die(mysql_error());//or die('db select error');
		}
	}

	function dbQuery($sql)
	{
		if(!$this -> dbConn)
		{
			$this -> dbConnect(true);
		}

		$rs = @mysql_query($sql,$this -> dbConn);
		
		if($_SERVER['REMOTE_ADDR'] == '112.216.100.226')
		{
			//echo $sql.";<br/>";
		}

		return $rs;
	}

	function dbGetOne($sql)
	{
		if(!$this -> dbConn)
		{
			$this -> dbConnect(true);
		}

		$rs = @mysql_query($sql,$this -> dbConn);

		$result = @mysql_result($rs,0,0);

		@mysql_free_result($rs);

		if($_SERVER['REMOTE_ADDR'] == '112.216.100.226')
		{
			//echo $sql.";<br/>";
		}

		return $result;
	}

	function dbGetLastIdx()
	{
		return @mysql_insert_id($this -> dbConn);
	}

	function dbChange($dbName)
	{
		@mysql_select_db($this -> $dbName,$this -> dbConn);
	}

	function dbClose()
	{
		@mysql_close($this -> dbConn);
	}
}

?>