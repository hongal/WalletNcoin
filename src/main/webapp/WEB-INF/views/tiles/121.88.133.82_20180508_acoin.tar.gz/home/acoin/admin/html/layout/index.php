<?php
/********************************************************************************

�����̸� : index.php
���ϼ��� : ���� ���̾ƿ�
�ۼ����� : 2012/01/17
�� �� �� : webwiz
��    �� : ���� ���̾ƿ�

- �������� -


********************************************************************************/

include_once $_SERVER['DOCUMENT_ROOT'].'/content/'.$view.'.php';

$totalHtml=<<<___wiz___

	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>$htmlTitle</title>
		<meta http-equiv="Content-Type" content="text/html; charset=euc-kr"/>
		<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi" name="viewport">
		<link href="css/{$styleSheet}" type="text/css" rel="stylesheet"/>
		<script type="text/javascript" src="js/jquery-1.5.2.min.js"></script>
		<script type="text/javascript" src="js/common.js?160122"></script>
		<script>
			// url bar hidden
			if(navigator.appVersion.indexOf('MSIE') == -1 && window.addEventListener != null)
			{
				window.addEventListener('load',function(){
					setTimeout(scrollTo, 0, 0, 1);
				},false);
			}
		</script>
		<script type="text/javascript">
			//<![CDATA[
				$javascript
			//]]>
		</script>
	</head>

	<body onload="$bodyOnload" bgcolor="#ffffff">

		$topHtml

		<!-- content -->
			$contentHtml
		<!-- //content -->

		$bottomHtml

	</body>
	</html>

___wiz___;

?>