/*
 * ListingTable by njh89z
 */

function ListingTable(data, options)
{
    try
    {
        data = JSON.parse(data);
    }
    catch (e)
    {
    }

    var created = new Date().getUTCMilliseconds();

    options.type = options.type?options.type:"ul";
    options.table = options.table?options.table:{"class":"table_templete_basic"};
    options.header = options.header?options.header:{};
    options.paging = options.paging?options.paging:{"class":"paging_templete_basic"};

    if(!options.columns || options.columns.length == 0)
    {
        throw "RequireColumnsException";
    }

    this.create = function() {
        var tags = options.type == "table"?{"table":"table", "column":"td", "row":"tr"}:{"table":"div", "column":"li", "row":"ul"};
        var listItems = [];

        listItems.push("<" + tags.table + " class=\"" + (options.table.class?options.table.class:"") + "\" style=\"" + (options.table.style?options.table.style:"") + "\" " + (options.table.attrs?options.table.attrs:"") + ">");

        // header
        if(options.header.isVisible !== false)
        {
            listItems.push("<" + tags.row + " class=\"header " + (options.header.class?options.header.class:"") + "\" style=\"" + (options.header.style?options.header.style:"") + "\" " + (options.header.attrs?options.header.attrs:"") + ">");

            $.each(options.columns, function(key, value) {
                listItems.push("<" + tags.column + " class=\"" + (value.class?value.class:"") + "\" style=\"" + (value.style?value.style:"") + "\" " + (value.attrs?value.attrs:"") + "><span>" + value.readableName + "</span></" + tags.column + ">");
            });

            listItems.push("</" + tags.row + ">");
        }

        // list
        $.each(data.list, function(key, value) {
            listItems.push("<" + tags.row + " class=\"list " + (options.rows&&options.rows.class?options.rows.class:"") + "\" style=\"" + (options.rows&&options.rows.style?options.rows.style:"") + "\" " + (options.rows&&options.rows.attrs?options.rows.attrs:"") + ">");

            $.each(options.columns, function(subKey, subValue) {
                var column_content = (value[subValue.name]!=null?value[subValue.name]:"&nbsp;");

                // content
                if (subValue.content) {
                    var column_content = subValue.content;

                    // variables
                    if (column_content.search(eval("/{{\\s*[a-zA-Z_][a-zA-Z0-9_\\-]*\\s*}}/gi")) >= 0) {

                        if (options.variables || subValue.variables) {
                            $.each($.extend({}, options.variables, subValue.variables), function(evalKey, evalValue) {
                                $.each(value, function(dataKey, dataValue) {
                                    column_content = column_content.replace(eval("/{{\\s*" + dataKey + "\\s*}}/gi"), dataValue);

                                    evalValue = evalValue.replace(eval("/{{\\s*" + dataKey + "\\s*}}/gi"), value[dataKey]);
                                });

                                column_content = column_content.replace(eval("/{{\\s*" + evalKey + "\\s*}}/gi"), eval(evalValue));
                            });
                        } else {
                            $.each(value, function(dataKey, dataValue) {
                                column_content = column_content.replace(eval("/{{\\s*" + dataKey + "\\s*}}/gi"), dataValue);
                            });
                        }
                    }
                }

                listItems.push("<" + tags.column + " id=\"" + created + "_column_" + key + "_" + subKey + "\" class=\"" + (subValue.class?subValue.class:"") + "\" style=\"" + (subValue.style?subValue.style:"") + "\" " + (subValue.attrs?subValue.attrs:"") + "><span>" + column_content + "</span></" + tags.column + ">");

                if(subValue.onclick != null) {
                    $(document).off("click","#" + created + "_column_" + key + "_" + subKey);
                    $(document).on("click","#" + created + "_column_" + key + "_" + subKey,value,subValue.onclick);
                }
                else if(options.rows&&options.rows.onclick != null) {
                    $(document).off("click","#" + created + "_column_" + key + "_" + subKey);
                    $(document).on("click","#" + created + "_column_" + key + "_" + subKey,value,options.rows.onclick);
                }
            });

            listItems.push("</" + tags.row + ">");
        });

        listItems.push("</" + tags.table + ">");

        // paging
        if(options.paging.isVisible !== false) {
	        var currentPage = 1
	        var totalPage = currentPage;
	
	        if(data.page)
	        {
	            currentPage = data.page.currentPage?data.page.currentPage:currentPage;
	            totalPage = data.page.totalPage?data.page.totalPage:totalPage;
	        }
	
	        currentPage = currentPage > totalPage ? totalPage : currentPage;
	
	        var pageSize = options.paging.size?options.paging.size:10;
	        var pageStart = Math.floor((currentPage - 1) / pageSize) * pageSize + 1;
	        var pageEnd = (pageStart + pageSize - 1) > totalPage ? totalPage : pageStart + pageSize - 1;
	
	        listItems.push("<div class=\"" + (options.paging.class?options.paging.class:"") + "\">");
	        var pages = '';
	
	        if(pageStart - pageSize > 0)
	        {
	            prevPage = pageStart - 1;
	            pages+="<span class=\"active\" id=\"" + created + "_paging_" + prevPage + "\">&lt;</span>";
	
	            if(options.paging.onclick != null)
	            {
	                $(document).on("click","#" + created + "_paging_" + prevPage,{"page":prevPage},options.paging.onclick);
	            }
	        }
	        else
	        {
	            prevPage = pageStart - 1;
	            pages+="<span class=\"disabled\" id=\"" + created + "_paging_" + prevPage + "\">&lt;</span>";
	        }
	
	        for(var i=pageStart;i<=pageEnd;i++)
	        {
	            if(i == currentPage)
	            {
	                pages+="<span class=\"current\" id=\"" + created + "_paging_" + i + "\">" + i + "</span>";
	            }
	            else
	            {
	                pages+="<span class=\"active\" id=\"" + created + "_paging_" + i + "\">" + i + "</span>";
	            }
	
	            if(options.paging.onclick != null)
	            {
	                $(document).on("click","#" + created + "_paging_" + i,{"page":i},options.paging.onclick);
	            }
	        }
	
	        if(pageStart + pageSize <= totalPage)
	        {
	            nextPage = pageEnd + 1;
	            pages+="<span class=\"active\" id=\"" + created + "_paging_" + nextPage + "\">&gt;</span>";
	
	            if(options.paging.onclick != null)
	            {
	                $(document).on("click","#" + created + "_paging_" + nextPage,{"page":nextPage},options.paging.onclick);
	            }
	        }
	        else
	        {
	            nextPage = pageEnd + 1;
	            pages+="<span class=\"disabled\" id=\"" + created + "_paging_" + nextPage + "\">&gt;</span>";
	        }
	
	        listItems.push(pages);
	        listItems.push("</div>");
	    }

        return listItems.join("\n");
    }

    this.appendTo = function(target) {
        $(target).append(this.create());
    }

    this.show = function(target) {
        $(target).html(this.create());
    }
}