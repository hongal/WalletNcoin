<?php
session_destroy();

redirectUrl($homeUrl);
?>