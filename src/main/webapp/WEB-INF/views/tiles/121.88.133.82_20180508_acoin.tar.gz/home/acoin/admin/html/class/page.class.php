<?php
/********************************************************************************

�����̸� : page.class.php
���ϼ��� : ����¡ Ŭ����
�ۼ����� : 2007/08/13
�� �� �� : webwiz
��    �� : ����¡ ó���� ���� Ŭ����

- �������� -


********************************************************************************/

class pageNavi
{
	var $totalCnt;
	var $articleCnt;
	var $pageCnt;
	var $curPage;
	var $url;

	function __construct($totalCnt,$articleCnt,$pageCnt,$curPage,$url)
	{
		global $homeUrl,$pageImg;

		$this -> totalCnt = $totalCnt;
		$this -> articleCnt = $articleCnt;
		$this -> pageCnt = $pageCnt;
		$this -> curPage = $curPage;
		$this -> url = $url;

		$totalPageCnt = ceil($this -> totalCnt / $this -> articleCnt);

		$startLimit = ($this -> curPage - 1) * $this -> articleCnt;

		$curBlock = ceil($this -> curPage / $this -> pageCnt);
		$totalBlock = ceil($totalPageCnt / $this -> pageCnt);

		$startPage = ($curBlock - 1) * $this -> pageCnt + 1;
		$endPage = $startPage + $this -> pageCnt;

		$linkUrl = $this -> url;

		if($endPage > $totalPageCnt)
		{
			$endPage = $totalPageCnt + 1;
		}

		$number = '';
		// Number
		for($i=$startPage;$i<$endPage;$i++)
		{
			if($i == $this -> curPage)
			{
				if($i == $pageCnt || $i == $endPage-1)
				{
					$number.="<td align='center' style='padding:2px 10px 0 10px;cursor:pointer;' bgcolor='#EDEDED' onclick=\"location.href='$homeUrl?$linkUrl&amp;page=$i';\"><a href='$homeUrl?$linkUrl&amp;page=$i' class='page_link2'>$i</a></td>";
				}
				else
				{
					$number.="<td align='center' style='padding:2px 10px 0 10px;cursor:pointer;' bgcolor='#EDEDED' onclick=\"location.href='$homeUrl?$linkUrl&amp;page=$i';\"><a href='$homeUrl?$linkUrl&amp;page=$i' class='page_link2'>$i</a></td><td width='1'><img src='$pageImg/page_line1.gif' alt=''/></td>";
				}
			}
			else
			{
				if($i == $pageCnt || $i == $endPage-1)
				{
					$number.="<td align='center' style='padding:2px 10px 0 10px;cursor:pointer;' onmouseover=\"this.style.backgroundColor='#EDEDED';childNodes[0].style.color='#FF3600';\" onmouseout=\"this.style.backgroundColor='#FFFFFF';childNodes[0].style.color='#3A3A3A';\" onclick=\"location.href='$homeUrl?$linkUrl&amp;page=$i';\"><a href='$homeUrl?$linkUrl&amp;page=$i' class='page_link1'>$i</a></td>";
				}
				else
				{
					$number.="<td align='center' style='padding:2px 10px 0 10px;cursor:pointer;' onmouseover=\"this.style.backgroundColor='#EDEDED';childNodes[0].style.color='#FF3600';\" onmouseout=\"this.style.backgroundColor='#FFFFFF';childNodes[0].style.color='#3A3A3A';\" onclick=\"location.href='$homeUrl?$linkUrl&amp;page=$i';\"><a href='$homeUrl?$linkUrl&amp;page=$i' class='page_link1'>$i</a></td><td width='1'><img src='$pageImg/page_line1.gif' alt=''/></td>";
				}
			}
		}

		$numberBox = $number;

		// prev, next
		if($curBlock <= 1)
		{
			$prev = "";
		}
		else
		{
			$prevPage = ($curBlock - 1) * $this -> pageCnt;
			$prev = "<a href='$homeUrl?$linkUrl&amp;page=$prevPage'><img src='$pageImg/page_but_before.gif' alt=''/></a>";
		}

		if($curBlock >= $totalBlock)
		{
			$next = "";
		}
		else
		{
			$nextPage = $curBlock * $this -> pageCnt + 1;
			$next = "<a href='$homeUrl?$linkUrl&amp;page=$nextPage'><img src='$pageImg/page_but_next.gif' alt=''/></a>";
		}

		// first, last
		if($this -> curPage > 1)
		{
			$first = "<a href='$homeUrl?$linkUrl&amp;page=1'><img src='$pageImg/page_but_start.gif' alt=''/></a>";
		}

		if($this -> curPage < $totalPageCnt)
		{
			$last = "<a href='$homeUrl?$linkUrl&amp;page=$totalPageCnt'><img src='$pageImg/page_but_end.gif' alt=''/></a>";
		}

		if(!$numberBox)
		{
			$numberBox = '<td></td>';
		}

		$this -> pageTable =<<<___ws___

			<table border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td align="left">$first $prev</td>
					<td align="center" style="padding:0 5px 0 5px">
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								$numberBox
							</tr>
						</table>
					</td>
					<td align="right">$next $last</td>
				</tr>
			</table>

___ws___;

		$this -> startLimit = $startLimit;
	}

	function getPageNavi()
	{
		return $this -> pageTable;
	}

	function startLimit()
	{
		return $this -> startLimit;
	}
}

?>