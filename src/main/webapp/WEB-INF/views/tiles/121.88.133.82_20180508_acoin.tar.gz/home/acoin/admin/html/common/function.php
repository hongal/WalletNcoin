<?php
function alertBack($message)
{
	$action=<<<___wiz___

		<script language="javascript" type="text/javascript">
			alert('$message');
			history.back();
		</script>

___wiz___;

	echo $action;
	exit;
}

function alertUrl($message,$inUrl)
{
	$action=<<<___ws___

		<script language="javascript" type="text/javascript">
			alert('$message');
			location.href = '$inUrl';
		</script>

___ws___;

	echo $action;
}

function alertCloseWin($message)
{
	$action=<<<___wiz___

		<script language="javascript" type="text/javascript">
			alert('$message');
			self.close();
		</script>

___wiz___;

	echo $action;
	exit;
}

// location.href
function redirectUrl($url)
{
	$action=<<<___wiz___

		<script language="javascript" type="text/javascript">
			location.href='$url';
		</script>

___wiz___;

	echo $action;
	exit;
}

function pointManager($pointType,$tradeType,$tradeCode,$actorId,$acteeId,$tradePoint,$content)
{	
	global $DB, $POINTADMIN;
	$tradePoint = abs($tradePoint);
	
	$requiredInputs = array('tradeType','tradeCode','actorId','acteeId','content');
	

	foreach($requiredInputs as $requiredInput)
	{
		if(!isset($$requiredInput))
		{
			//echo $requiredInput;
			return 1;
		}
	}

	$allowedPointTypes = array(
		'ruby',
		'gold',
		'darkElixir',
		'elixir'
	);

	if(!in_array($pointType, $allowedPointTypes))
	{
		return 1;
	}

	// check member
	$sql1 = "select * from member where idx='$actorId'";
	$rs1 = $DB -> dbQuery($sql1);
	$actor = @mysql_fetch_array($rs1);
	@mysql_free_result($rs);

	$sql2 = "select * from member where idx='$acteeId'";
	$rs2 = $DB -> dbQuery($sql2);
	$actee = @mysql_fetch_array($rs2);
	@mysql_free_result($rs2);
	
	if(!$actor['idx'] || !$actee['idx'])
	{
		$resultCode = 2;
	}
	else
	{
		$content = addslashes($content);

		if($tradeType == 'give')
		{
			$getter = $actee;
			$loser = $actor;
		}
		else if($tradeType == 'take')
		{
			$getter = $actor;
			$loser = $actee;
		}
		else
		{
			return 1;
		}
		
		if($loser[$pointType] < $tradePoint)
		{			
			$resultCode = 3;
		}
		else
		{
			$getter['tradePoint'] = $tradePoint;
			$loser['tradePoint'] = $tradePoint;

			//getter�� �ڿ��ִ����差�� �Ѿ�� �ִ����差���� ����
			if($pointType != 'ruby' && $getter['idx'] != $POINTADMIN)
			{
				$max = getMaxOfResource($getter['idx'], $pointType);

				if($max < $getter[$pointType] + $tradePoint)
				{
					//$getter[$pointType] = $max;
					$diff = $max - $getter[$pointType];
					$getter['tradePoint'] = $diff;
				}
			}

			$getter[$pointType] += $getter['tradePoint'];
			$loser[$pointType] -= $loser['tradePoint'];

			$sql1 = "update member set $pointType='$getter[$pointType]' where idx = '$getter[idx]'";
			$sql2 = "update member set $pointType='$loser[$pointType]' where idx= '$loser[idx]'";
			
			$pointQueryForGetter = ", used".ucfirst($pointType)."='".$getter['tradePoint']."'";
			$pointQueryForLoser = ", used".ucfirst($pointType)."='".$getter['tradePoint']."'";

			foreach($allowedPointTypes as $value)
			{	
				$pointQueryForGetter .= ",total".ucfirst($value)."='".$getter[$value]."'";
				$pointQueryForLoser .= ",total".ucfirst($value)."='".$loser[$value]."'";				
			}

			if (strpos($tradeCode,'|') > 0)
			{
				$tradeCodeExp = explode('|',$tradeCode);
				$tradeCode = $tradeCodeExp[0];
				$payCode = $tradeCodeExp[1];
			}
			else
			{
				$payCode = '';
			}

			$sql3 ="insert into pointLog set pointType='$pointType',tradeType='take',tradeCode='$tradeCode',payCode='$payCode',userid='$getter[idx]',tradeid='$loser[idx]',content='$content',regDate=now(),ipAddr='$_SERVER[REMOTE_ADDR]' {$pointQueryForGetter} ";

			$sql4 ="insert into pointLog set pointType='$pointType',tradeType='give',tradeCode='$tradeCode',payCode='$payCode',userid='$loser[idx]',tradeid='$getter[idx]',content='$content',regDate=now(),ipAddr='$_SERVER[REMOTE_ADDR]' {$pointQueryForLoser} ";
			
			if($tradeType == 'give')
			{
				$sqlArray = array($sql1,$sql2,$sql4,$sql3);
				$errorCdoe = 4;
			}
			else
			{
				$sqlArray = array($sql1,$sql2,$sql3,$sql4);
				$errorCode = 6;
			}

			foreach($sqlArray as $sql)
			{
				$rs = $DB -> dbQuery($sql);
				if(!$rs)
				{
					$resultCode = $errorCode;
					break;
				}
			}

			if($errorCode != 6 || $errorCode != 4)
			{
				$resultCode = 9;
			}

		}	
	}

	if($resultCode == 9)
	{
		$result = 'success';
	}
	else
	{
		$result = $resultCode;
	}

	return $result;
}

function getMaxOfResource($user_id, $resourceType)
{
	global $DB;

	$storageKey = 0;

	if($resourceType == 'gold')
	{
		$storageKey = 2;
	}
	else if($resourceType == 'elixir')
	{
		$storageKey = 4;
	}
	else if($resourceType == 'darkElixir')
	{
		$storageKey = 6;
	}

	$max = 1000;

	
	if($storageKey != 0)
	{
		$sql = "select capacity from users_buildings as A join levels as B on A.building_key = B.subject_key and B.subject_type = 'building' and A.level =  B.stage where A.user_id = '$user_id' and B.subject_key = '$storageKey'";

		$rs = $DB -> dbQuery($sql);
		while($result = @mysql_fetch_array($rs))
		{
			$max += $result['capacity'];
		}

		@mysql_free_result($rs);
	}
	
	return $max;

}
//
//function pointManager($tradeType,$tradeCode,$userid,$tradeid,$tradePoint,$content)
//{
//	global $DB,$POINTADMIN;
//
//	if(!$tradeType || !$tradeCode || !$userid || !$tradeid || !$content)
//	{
//		$resultCode = 1;
//	}
//	else
//	{
//		// check member
//		$sql1 = "select * from member where idx='$userid'";
//		$rs1 = $DB -> dbQuery($sql1);
//
//		$result1 = @mysql_fetch_array($rs1);
//		@mysql_free_result($rs);
//
//		$sql2 = "select * from member where idx='$tradeid'";
//		$rs2 = $DB -> dbQuery($sql2);
//
//		$result2 = @mysql_fetch_array($rs2);
//		@mysql_free_result($rs2);
//
//		if(!$result1['idx'] || !$result2['idx'])	// ȸ�� ���翩�� üũ
//		{
//			$resultCode = 2;
//		}
//		else
//		{
//			$content = addslashes($content);
//
//			if($tradeType == 'give')	// ����Ʈ ����
//			{
//				$tradeType2 = 'take';
//
//				// point check
//
//				if($userid != $POINTADMIN && $result1['point'] < $tradePoint)
//				{
//					$resultCode = 3;
//				}
//				else
//				{
//					$takePoint = $result1['point']-$tradePoint;
//					$givePoint = $result2['point']+$tradePoint;
//
//					// trade point
//					$sql1 = "update member set point='$takePoint' where idx='$userid'";
//					$rs1 = $DB -> dbQuery($sql1);
//
//					$sql2 = "update member set point='$givePoint' where idx='$tradeid'";
//					$rs2 = $DB -> dbQuery($sql2);
//
//					// write log
//					$sql3 = "insert into pointLog set tradeType='$tradeType',tradeCode='$tradeCode',userid='$userid',tradeid='$tradeid',usedPoint='$tradePoint',totalPoint='$takePoint',content='$content',regDate=now(),ipAddr='$_SERVER[REMOTE_ADDR]'";
//					$rs3 = $DB -> dbQuery($sql3);
//
//					$sql4 = "insert into pointLog set tradeType='$tradeType2',tradeCode='$tradeCode',userid='$tradeid',tradeid='$userid',usedPoint='$tradePoint',totalPoint='$givePoint',content='$content',regDate=now(),ipAddr='$_SERVER[REMOTE_ADDR]'";
//					$rs4 = $DB -> dbQuery($sql4);
//
//					if($rs1 && $rs2 && $rs3 && $rs4)
//					{
//						$resultCode = 9;
//					}
//					else
//					{
//						$resultCode = 4;
//					}
//				}
//			}
//			else if($tradeType == 'take')	// ����Ʈ ȸ��
//			{
//				$tradeType2 = 'give';
//
//				// point check
//				if($tradeid != $POINTADMIN &&  $result2['point'] < $tradePoint)
//				{
//					$resultCode = 5;
//				}
//				else
//				{
//					$takePoint = $result2['point']-$tradePoint;
//					$givePoint = $result1['point']+$tradePoint;
//
//					// trade point
//					$sql1 = "update member set point='$takePoint' where idx='$tradeid'";
//					$rs1 = $DB -> dbQuery($sql1);
//
//					$sql2 = "update member set point='$givePoint' where idx='$userid'";
//					$rs2 = $DB -> dbQuery($sql2);
//
//					// write log
//					$sql3 = "insert into pointLog set tradeType='$tradeType',tradeCode='$tradeCode',userid='$userid',tradeid='$tradeid',usedPoint='$tradePoint',totalPoint='$givePoint',content='$content',regDate=now(),ipAddr='$_SERVER[REMOTE_ADDR]'";
//					$rs3 = $DB -> dbQuery($sql3);
//
//					$sql4 = "insert into pointLog set tradeType='$tradeType2',tradeCode='$tradeCode',userid='$tradeid',tradeid='$userid',usedPoint='$tradePoint',totalPoint='$takePoint',content='$content',regDate=now(),ipAddr='$_SERVER[REMOTE_ADDR]'";
//					$rs4 = $DB -> dbQuery($sql4);
//
//					if($rs1 && $rs2 && $rs3 && $rs4)
//					{
//						$resultCode = 9;
//					}
//					else
//					{
//						$resultCode = 6;
//					}
//				}
//			}
//		}
//	}
//
//	if($resultCode == 9)
//	{
//		$result = 'success';
//	}
//	else
//	{
//		$result = $resultCode;
//	}
//
//	return $result;
//}

function mobileChk($mobile)
{
	$pattern = '/[^0-9]/';
	if (preg_match($pattern,$mobile,$matches))
	{
		$result = 'error';
	}
	else
	{
		if (strlen($mobile) == 11)
		{
			$result = substr($mobile,0,3).'-'.substr($mobile,3,4).'-'.substr($mobile,7,4);
		}
		else if (strlen($mobile) == 10)
		{
			$result = substr($mobile,0,3).'-'.substr($mobile,3,3).'-'.substr($mobile,6,4);
		}
		else
		{
			$result = 'error';
		}
	}
	if ($mobile && $result == 'error')
	{
		//alertBack('�߸��� �����Դϴ�.');
	}
	return $result;
}

function dateDiff($mode,$dateS,$dateE)
{
	$dateSArr = explode('-',$dateS);

	$yearS = $dateSArr[0];
	$monthS = $dateSArr[1];
	$dayS = $dateSArr[2];

	$dateEArr = explode('-',$dateE);

	$yearE = $dateEArr[0];
	$monthE = $dateEArr[1];
	$dayE = $dateEArr[2];

	$yearChk = $yearE - $yearS;
	$monthChk = $monthE - $monthS;

	if($mode == 'year')
	{
		$return = $yearChk;
	}
	else if($mode == 'month')
	{
		$return = ($yearChk * 12) + $monthChk;
	}
	else if($mode == 'day')
	{
		$return = (strtotime($dateE) - strtotime($dateS)) / (60 * 60 * 24);
	}

	return $return+1;
}

function dateFunction($time)
{
	if ($time > 0)
	{
		$calcTime = time() - $time;
		if ($calcTime < 0)
		{
			$returnVal = '0����';
		}
		else
		{
			if ($calcTime < 60)
			{
				$returnVal = $calcTime.'����';
			}
			else if ($calcTime < 60 * 60)
			{
				$returnVal = number_format($calcTime / 60).'����';
			}
			else if ($calcTime < 60 * 60 * 24)
			{
				$returnVal = number_format($calcTime / (60 * 60)).'�ð���';
			}
			else if ($calcTime < 60 * 60 * 24 * 7)
			{
				$returnVal = number_format($calcTime / (60 * 60 * 24)).'����';
			}
			else if ($calcTime < 60 * 60 * 24 * 7 * 4)
			{
				$returnVal = number_format($calcTime / (60 * 60 * 24 * 7)).'����';
			}
			else
			{
				$returnVal = number_format($calcTime / (60 * 60 * 24 * 30)).'������';
			}
		}
	}
	else
	{
		$returnVal = 0;
	}
	return $returnVal;
}

function randString($length)
{
	$result = '';

	for($i=0;$i<$length;$i++)
	{
		mt_srand((double)microtime()*1000000);
		$result.= substr('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', mt_rand(0,61),1);
	}

	return $result;
}

function utf8($str)
{
	return iconv('cp949','utf-8',$str);
}

function cp949($str)
{
	return iconv('utf-8','cp949',$str);
}

function sendAdminChatMsg($targetid, $msg)
{
	global $DB;
	global $CHATADMIN;
	
	$sql = "select * from member where idx='$targetid'";
	$rs = $DB -> dbQuery($sql);
	$result = @mysql_fetch_array($rs);
	$targetNickname = $result['nickname'];
	$targetSex = $result['targetSex'];
	$targetBirthYear = $result['targetBirthYear'];
	
	@mysql_free_result($rs);

	$distance = '???km';
	$msgType = 'text';
	$photoYN = 'N';

	$userid = $CHATADMIN;
	$nickname = '������';
	$sex = 'F';
	$birthYear = '1991';

	$sql = "insert into chat set userid='$userid',nickname='$nickname',sex='$sex',birthYear='$birthYear',targetid='$targetid',targetNickname='$targetNickname',targetSex='$targetSex',targetBirthYear='$targetBirthYear',distance='$distance',msgType='$msgType',msg='$msg',photoYN='$photoYN',regDate=now(),ipAddr='$_SERVER[REMOTE_ADDR]'";
	$rs = $DB -> dbQuery($sql);

	if($rs)
	{
		$pushMsg = $msg;
		$pushType = 0;
		androidPushReady($userid, $nickname, $targetid, $pushMsg, $pushType);
	}
}

?>